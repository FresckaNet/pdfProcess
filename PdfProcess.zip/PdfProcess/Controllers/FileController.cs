using Microsoft.AspNetCore.Mvc;
using Services.Services;

namespace PdfProcess.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class FileController : ControllerBase
    {

        private readonly ILogger<FileController> _logger;
        private PdfServices pdfServices;

        public FileController(ILogger<FileController> logger)
        {
            _logger = logger;
        }

        [HttpPost(Name = "upload")]
        public IActionResult UploadFile( IFormFile file)
        {
            if (file == null || file.Length == 0)
                return BadRequest("No se seleccion� ning�n archivo");
            var filePath = Path.Combine(Directory.GetCurrentDirectory(), "uploads", file.FileName);
            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                file.CopyToAsync(stream);
            }

            pdfServices = new PdfServices();

            var readFile = pdfServices.readPdf(filePath);


            return Ok(new { readFile.Text });
        }
    }
}
