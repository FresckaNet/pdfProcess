﻿using System;
using System.IO;
using DataAcces.Entities;
using iText.Kernel.Pdf;
using iText.Kernel.Pdf.Canvas.Parser;
using iText.Kernel.Pdf.Canvas.Parser.Listener;

public class PdfTextExtractor
{
    public string ExtractInformation(string pdfFilePath)
    {
        var newFile = new PdfWebFile();

        PdfReader reader = new PdfReader(pdfFilePath);
        PdfDocument pdfDoc = new PdfDocument(reader);
        {
            for (int page = 1; page <= pdfDoc.GetNumberOfPages(); page++)
            {
                ITextExtractionStrategy strategy = new SimpleTextExtractionStrategy();
                string text = GetTextFromPage(pdfDoc.GetPage(page), strategy);
                newFile.text += text;
            }
            return newFile.text;
        }
    }

    private static string GetTextFromPage(PdfPage page, ITextExtractionStrategy strategy) 
    { 
        return PdfTextExtractor.GetTextFromPage(page, strategy); 
    }
}
