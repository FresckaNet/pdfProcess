﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataAcces.Entities
{
    public class PdfWebFile
    {
        public string fileName;
        public string text;
    }
}
